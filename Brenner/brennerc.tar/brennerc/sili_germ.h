#ifndef SILI_GERM_H
#define SILI_GERM_H

#include "brenner.h"

Float sili_germ(struct State *info, struct AtomPairInfoState *apis);
#endif
