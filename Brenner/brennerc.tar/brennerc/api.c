/*
 This code was released into the public domain by Tim Freeman on 11 Aug 2000.
*/

#ifndef __API_H__
#include "api.h"
#endif

/* No code here.  It's just a compilation check. */
