/*
** This is a simulated world using C++. Feb.3,1993 LiJu.
*/

#include <string.h>
#include <malloc.h>
#include <iostream.h>


/*
** The Base class for everything in the world.
*/

class Object 
{
 protected:
  char *type, *name;
  float age,size,weight;
  
 public:
  float x,y,z;

  Object()
    {
      x=y=z=age=size=weight=0.;
    }

  void SetType(char * a="Unknown") 
   {
     type = (char *)malloc(strlen(a));
     strcpy(type,a); 
   }
  
  void SetName(char * a="Unknown") 
    {
      name = (char *) malloc(strlen(a));
      strcpy(name,a);
    }
  
  // the destructor.
  ~Object()
    {
      cout<<"Object destructor...\n";
      cout<<"type "<<type<<" name "<<name<<" perished.\n\n";
      free(type);
      free(name);
     }
};
 
/*
** Animal, that is the kind of object that can move,
** and with sex...well, maybe.
*/
class Animal : public Object
{
 private:
  char * secret;
  char * Animal_Type;

 protected:
  int gender;

 public: 

  void SetType(char * a="Unknown") 
   {
     Animal_Type = (char *) malloc(strlen(a));
     strcpy(Animal_Type,a);
   }

  Animal(char *ANIMAL_TYPE="Unknown",char * NAME="Unknown")
   {
    
    /* Here we use the overloaded function SetType to set 
       Animal_Type(cat,snake,etc.), not type of the object. */

    SetType(ANIMAL_TYPE);
    Object::SetType("Animal");
    Object::SetName(NAME);
    cout << "The Animal constructor...\n"
         << "Construct a "<<ANIMAL_TYPE<<" with name "<<NAME<<"\n\n";
   }

  virtual int move(float,float)=0; 
  // Have to declare it's a pure virtual function.

  ~Animal()
    {
      cout << "Animal destructor...";
      cout << "a "<<Animal_Type<<" died.\n\n";
      free(Animal_Type);
    }

};

class Tiger : public Animal
{
 public:

  // 
  Tiger(char *a="Unknown")
   {
   Animal::Animal("Tiger",a);
   cout << "Tiger constructor... A TIGER is born! Howwua! King of the Junge!\n\n";
   }

  virtual int move(float dx,float dy)
    {
      x+=dx;
      y+=dy;
      cout<<"The tiger "<<name<<" runs to ("<<x<<','<<y<<")\n\n";
    }
 
  ~Tiger()
    {
     cout<< "Tiger destructor... The king died!!!\n\n";
     }

};


int main(int argc,char *argv[])
{
 Tiger Xiao("Xiao");
 Xiao.move(1,2.);
}






