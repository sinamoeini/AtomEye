#include <iostream.h>
#include "complex.h"

void ss (Complex w[500][500])
{
}

int main()
{
  Complex w[500][500];
  return(1);
}
