function print()
global a;

clf;
if exist('a')==0
 load a.out;
end;

c(474) = 0;
c(526) = 0;
for i = 475:525
c(i) = 1;
end;

i = 1:1000;

for n = 1:7
 subplot(7,2,2*n-1);
 plot(a(i));
 hold on;
 j = 474:526;
 plot (j,c(j));
 axis ([1 700 0 2]);
 axis ('off');
 text (670,0.5,['T = ',int2str(i(1)/1000*20)]);
 i = i+3000;
end;

for n = 1:7
 subplot(7,2,2*n);
 plot(a(i));
 hold on;
 j = 474:526;
 plot (j,c(j));
 axis ([1 900 0 2]);
 axis ('off');
 text (670,0.5,['T = ',int2str(i(1)/1000*20)]);
 i = i+3000;
end;

end;
