function mess(n)

load(['a' n '.out']);
eval (['a = a' n ';' ]);

mesh (a);
title (['t = ' num2str(str2num(n)*30)]);
eval (['print /mit/bitbucket/liju/surf' n '.ps;']);

contour (a,4);
title (['t = ' num2str(str2num(n)*30)]);
eval (['print /mit/bitbucket/liju/contour' n '.ps;']);

end;

