
function show()
global a;

clf;
if exist('a')==0
 load a.out;
end;

shot = size(a);
i=1:1000;
for j=1:shot(1)/1000-1
 i = i+1000;
 plot(a(i));
 axis([0 1000 0 2]);
 title(['Time Step =' num2str((j-1)*20)]);
% ss=input('Hit Return to continue ','s');
 pause (0.5);
 clf;
end;

end;
 
