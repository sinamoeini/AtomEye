#include <iostream.h>
#include "complex.h"

main()
{
 Complex x[10];
}
