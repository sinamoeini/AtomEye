#include <stdio.h>
#include <malloc.h>

#define NODE    4
#define NO      16
#define PATTERN 3

struct Config 
{
 float energy;
 int   STATUS;
};
struct Config every[NO];
unsigned int U[PATTERN]={15,12,10};

void trans(int i,int j[NODE]);
float energy(int i,float j[NODE][NODE]);

void main()
{
  unsigned int i,m,n,mask;
  int x[NODE],y[NODE];
  float j[NODE][NODE]={0},j1[NODE][NODE]={0};

  for (m=0;m<PATTERN;m++)
    {
      trans(U[m],x);
      for (i=0;i<NODE;i++)
	for (n=0;n<NODE;n++)
	  j[i][n]+=x[i]*x[n];
    }

  for (i=0;i<NODE;i++)
    for (n=0;n<NODE;n++)
	j[i][n]/=NODE;

  for (n=0;n<NO;n++)
    every[n].energy=energy(n,j);

  for (n=0;n<NO;n++)
    {
      trans(n,x);
      printf("%2d%2d%2d%2d  energy=%f  ",x[3],x[2],x[1],x[0],every[n].energy);
      m=1;
      for (i=0;i<NODE;i++)
	{
	  mask = 1<<i;
	  if (every[n].energy>every[n^mask].energy)
	    {
	      m = 0;
	    }
          else 
	    if(every[n].energy==every[n^mask].energy)
	    {
	      m=2;
	    }
	}
      every[n].STATUS=m;
      if (m==1)
	printf("Status=Local Minimum\n");
      else if(m==2) printf("Status=Frustration\n");
      else if(m==0) printf("\n");
    }
return;
}

void trans(i,j)
int i;
int j[NODE];
{
  int m;
  for (m=0;m<NODE;m++)
   j[m]=((i>>m)&1)*2-1;
  return;
}

float energy(i,J)
int i;
float J[NODE][NODE];
{
 int m,n;
 float result;
 int a[NODE];
 trans(i,a);
 result = 0;
 for (m=0;m<NODE;m++)
   for (n=0;n<NODE;n++)
     result+=a[m]*a[n]*J[m][n]*(-1);
 return(result);
}
    

