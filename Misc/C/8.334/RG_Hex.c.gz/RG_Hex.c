/*
** Renormalization Group Decimation for 2D
** Hexagonal lattice Ising Model. (Term collector) 
** See 8.334 Problem Set 7.3  
** April.5,1995      Li Ju.
*/

#define MAXTERM 100
#include <stdio.h>

void main()
{
  int i1,i2,i3,i4;  /* One primed square */ 
  int i5,i6,i7,i8;  /* The adjacent one  */
  
  int Egterms[4][MAXTERM][MAXTERM]={0};
  
/*
** # of each term for R(++),R(+-),R(-+),R(--).
** 1st index: 0=(--), 1=(-+), 2=(+-), 3=(++).
** 2nd index: coefficients of J. 
** 3rd index: coefficients of H.
*/

  int who,CJ,CH; /* Conuter for J,H */
  int S1,S2;

  for (i1=-1;i1<=1;i1+=2)
  for (i2=-1;i2<=1;i2+=2)
  for (i3=-1;i3<=1;i3+=2)
  for (i4=-1;i4<=1;i4+=2)
  for (i5=-1;i5<=1;i5+=2)
  for (i6=-1;i6<=1;i6+=2)
  for (i7=-1;i7<=1;i7+=2)
  for (i8=-1;i8<=1;i8+=2)
    {
      CH = 0;
/*      CH = (i1+i2+i3+i4+i5+i6+i7+i8);  */

      CJ = (i1+i2+i3)*i4+(i5+i6+i7)*i8+i3*i5+i2*i6;
      
      S1 = i1+i2+i3;
      S2 = i5+i6+i7;

      if ((S1>0)&&(S2>0)) who = 3;
      if ((S1>0)&&(S2<0)) who = 2;   
      if ((S1<0)&&(S2>0)) who = 1;   
      if ((S1<0)&&(S2<0)) who = 0;   
      
      Egterms[who][CJ+20][CH+20]++;
    }

  for (who=0;who<=3;who++)
    {
      if (who==0) printf("R(--):\n");
      if (who==1) printf("R(-+):\n");
      if (who==2) printf("R(+-):\n");
      if (who==3) printf("R(++):\n");
      
      for (CJ=0;CJ<MAXTERM;CJ++)
	for (CH=0;CH<MAXTERM;CH++)
	  if (Egterms[who][CJ][CH]!=0)
	    printf("%d exp(%dJ) terms. \n",Egterms[who][CJ][CH], \
		   CJ-20);
      printf("\n\n");
    }

}







