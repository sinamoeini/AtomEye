/***************************************************/
/* 2D XY model showing Stanley-Kaplan phase.       */
/* Midgal-Kadanoff RG treatment. See 8.334 PS.9    */
/* Li Ju. Apr.29, 1995                             */
/***************************************************/

#include <stdio.h>
#include <math.h>

#define MAXFC   20        /* Max # of Fourier components */
#define MAXSTEP 200000    /* Max steps of iteration      */
#define ACCU 1E-4         /* accuracy of V(theta) convergence */
#define PI   3.1415926

float T,J;  /* reduced coupling temperature, energy */
float bessi0(float x);
float bessi1(float x);

int main()
{
  float  Jv;
  long   p,q,qq,pq,j,step;
  double f1[MAXFC+2],f2[MAXFC+2]={0};
  double A[MAXSTEP+1],AA,BB,F;
  FILE   * OUTPUT;
  int OK;
  
  OUTPUT = fopen  ("fv.out","w");
  
 for (T=0.88;T<0.89;T+=0.001)
    {
  J = 1/T;
  printf ("T = %f\n",T);
  
  /* Modified Bessel function of integer order */
  /* Backward recursion since it's unstable.   */

  AA = bessi0(J)*exp(-J);
  f1[MAXFC+1] = 0;
  f1[MAXFC]   = 1;
  for (p=MAXFC;p>=1;p--)
    f1[p-1] = f1[p+1]+2*p*f1[p]/J;

  for (p=MAXFC;p>=0;p--)
    f1[p] *= AA/f1[0];

  OK = 1;
  BB = 4;
  for (step=1;OK;step++)
    {
      for (p=0;p<=MAXFC;p++)
	{
	  f2[p]=0;
	  for (q=-MAXFC;q<=MAXFC;q++)
	    {
	      qq = q;
	      pq = p-q;
	      if (qq<0) qq = -qq;
	      if (pq<0) pq = -pq;
	      if (pq>MAXFC) pq = MAXFC+1;
	      f2[p]+=f1[qq]*f1[pq];
	    }
	  f2[p]*=f2[p];
	}
      
      AA = 0;
      for (p=1;p<=MAXFC;p++)
	AA += f2[p];
      AA=2*AA+f2[0];
      A[step] = log(AA)/BB;
      BB *= 4;

      for (p=0;p<=MAXFC;p++)
	f2[p]/=AA;
      
      if (fabs(f2[0]/f1[0]-1)<ACCU) OK = 0;
      for (p=0;p<=MAXFC;p++) f1[p] = f2[p];
    }
      
  printf ("%d\n",step);
  for (F=0;step>=1;step--)
    F += A[step];

  fprintf(OUTPUT,"%f\n",T);
}
  fclose (OUTPUT);
  return(1);
}

float bessi0(x)
float x;
{
        float ax,ans;
        double y;

        if ((ax=fabs(x)) < 3.75) {
                y=x/3.75;
                y*=y;
                ans=1.0+y*(3.5156229+y*(3.0899424+y*(1.2067492
                        +y*(0.2659732+y*(0.360768e-1+y*0.45813e-2)))));
        } else {
                y=3.75/ax;
                ans=(exp(ax)/sqrt(ax))*(0.39894228+y*(0.1328592e-1
                        +y*(0.225319e-2+y*(-0.157565e-2+y*(0.916281e-2
                        +y*(-0.2057706e-1+y*(0.2635537e-1+y*(-0.1647633e-1
                        +y*0.392377e-2))))))));
        }
        return ans;
}

float bessi1(x)
float x;
{
        float ax,ans;
        double y;

        if ((ax=fabs(x)) < 3.75) {
                y=x/3.75;
                y*=y;
                ans=ax*(0.5+y*(0.87890594+y*(0.51498869+y*(0.15084934
                        +y*(0.2658733e-1+y*(0.301532e-2+y*0.32411e-3))))));
        } else {
                y=3.75/ax;
                ans=0.2282967e-1+y*(-0.2895312e-1+y*(0.1787654e-1
                        -y*0.420059e-2));
                ans=0.39894228+y*(-0.3988024e-1+y*(-0.362018e-2
                        +y*(0.163801e-2+y*(-0.1031555e-1+y*ans))));
                ans *= (exp(ax)/sqrt(ax));
        }
        return x < 0.0 ? -ans : ans;
      }











