/*
**  This program is to get the magentization distribution
**  of a semi-infinite ferromagnetic slab. (on z sirection)
**  See 8.334 problem set 2, problem 4.   Feb.21,1995 Li Ju.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* accuracy of the result */
# define ACCU  0.0000001
# define MAXLENGTH 10000

int main(int argc, char * argv[])
/* Input J and q 
** J is the coupling coefficient;
** q is the # of nearest neighbours.
*/
{
 double J,mm,old;
 double solve();
 long i,j,k;
 double m[MAXLENGTH+2];
 int q;

 if ((argc<=1)||(argc>3)) 
   {
     fprintf(stderr,"Error, must input J and q.\n");
     exit(0);
   }
 else
   if (argc==2) q = 6; /* Three dimensional */
 else
   q = atoi(argv[2]);

 J = atof(argv[1]);

 mm = solve(J*q);

 for (i=1;i<=MAXLENGTH+1;i++)
   m[i] = mm;

 do 
   {
     old = m[1];
     m[1] = tanh(J*((q-2)*m[1]+m[2]));
     for (i=2;i<=MAXLENGTH;i++)
       m[i] = tanh(J*((q-2)*m[i]+m[i-1]+m[i+1]));
   }
 while (fabs(m[1]-old)>ACCU);

 for (i=1;i<=1000;i++)
   fprintf (stdout,"%lf \n",m[i]);
 return(1);
}

/* 
** solve the self-consistent equation tanh(am) = m,
** (give the positive value) 
*/ 
double solve (double a)
{
  double m1=0,m2=1.0,m3,dy;
  while (m2-m1 > ACCU)
    {
      m3 = (m1+m2)/2.;
      dy = tanh(a*m3)-m3;
      if (dy>0) m1 = m3;
       else m2 = m3;
    }
  return(m3);
}




