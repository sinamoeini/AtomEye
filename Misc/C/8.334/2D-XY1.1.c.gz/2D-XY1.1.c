/***************************************************/
/* 2D XY model showing Stanley-Kaplan phase.       */
/* Midgal-Kadanoff RG treatment. See 8.334 PS.9    */
/* Li Ju. Apr.29, 1995                             */
/***************************************************/
/* Calculate 2nd-order phase boundary for          */
/* biquadratic interaction.                        */
/***************************************************/

#include <stdio.h>
#include <math.h>

#define MAXFC   9         /* Max # of Fourier components */
#define CONVO   50        /* Range of convolution:       */
#define JV      0.915     /* extrapolation at the end,   */
			  /* in order to minimize error. */

#define MAXSTEP 100000   /* Max steps of iteration      */
#define ACCU 1E-4       /* accuracy of V(theta) convergence */
#define INTNO 20000     /* intergration steps               */
#define PI   3.1415926

float T,J,K;  /* reduced coupling temperature, energy */

int main()
{
  float  Jv=JV;
  long   p,q,qq,pq,j,step;
  double f1[CONVO+1]={0},f2[CONVO+1]={0};
  double A[MAXSTEP+1],AA;
  double inc,phi,s;
  FILE   * OUTPUT;
  int OK;

  K = 0.18;
  OUTPUT = fopen  ("fv.out","w");
  for (T=1.10;;T+=0.001)
    {
      printf ("T = %f\n",T);
      J = 1/T;
      inc = PI/INTNO;
      for (p=0;p<MAXFC;p++)
	{
	  f1[p]=0;
	  phi = 0.;
	  for (j=1;j<=INTNO;j++)
	    {
	      s = cos(phi);
	      f1[p]+=cos(p*phi)*exp(J*(s-1)+K*(s*s-1));
	      phi  += inc;
	    }
	  f1[p] *= inc/PI;
	  printf ("Wave No.%d intergrated over, fp=%f\n",p,f1[p]);
	}

      OK =1;
      for (step=1;OK;step++)
	{
	  for (p=MAXFC;p<CONVO;p++)
	    f1[p] = f1[p-1]*exp((1-2*p)/2./Jv);
	  /* extrapolation scheme for those wave components    */
	  /* outside computation range. Using previous Jv.     */
	  
	  for (p=0;p<MAXFC;p++)
	    {
	      f2[p]=0;
	      for (q=-CONVO+1;q<CONVO;q++)
		{
		  qq = q;
		  pq = p-q;
		  if (qq<0) qq = -qq;
		  if (pq<0) pq = -pq;
		  if (pq>=CONVO) pq = CONVO-1;
		  f2[p]+=f1[qq]*f1[pq];
		}
	      f2[p]*=f2[p];
	    }
	  
	  AA = 0;
	  for (p=1;p<MAXFC;p++)
	    AA += f2[p];
	  AA=2*AA+f2[0];

	  for (p=0;p<MAXFC;p++)
	    f2[p]/=AA;

	  if (fabs(f2[0]/f1[0]-1)<ACCU) OK = 0;
	  for (p=0;p<MAXFC;p++) f1[p] = f2[p];
	}
    
      printf ("%d\n",step);
      fprintf (OUTPUT,"%f\t%d\t%f\n",T,step,f1[0]);
    }

  fclose (OUTPUT);
  return(1);
}
  











