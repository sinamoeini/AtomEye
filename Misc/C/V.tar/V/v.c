/***************************************/
/*  View 1.0                           */
/*                                     */
/*  Threaded X-window 2D Object Group  */
/*  Animator.                          */
/*                                     */
/*             Ju Li Nov.26 1998 MIT   */
/***************************************/

/*
  Version Notes:
  1.0 --
  Multiple displays;
  Threaded animation
  (not available on Linux);
  Instance by signal;
*/

#include "v.h"
#define DEFAULT_FACTOR (0.01)
#define key_verify(a,b,c) (b==(a)c)
struct OGL
{
    char token[V_MAX_OG_TOKEN_SIZE];
    int obj_type;
    int n; /* number of objects in group */
    void *gp; /* group array pointer */
    struct OGL *next;
};

/** The scope of following is within **/
static volatile double (*H)[2];
static volatile Bool active[V_MAXWINDOW],
    LockOGL, OGLRendered[V_MAXWINDOW],
    PBC[V_MAXWINDOW];
/* the above can be modified by the main */
/* thread without notice, thus volatile. */
static pid_t master_pid;
static struct OGL oglpool[V_MAX_NUM_OGS]={0};
static char display_address[V_MAXWINDOW][V_MAX_STRLEN],
    title[V_MAXWINDOW][V_MAX_STRLEN];
static Display *display[V_MAXWINDOW];
static int screen[V_MAXWINDOW];
static Window root[V_MAXWINDOW],windows[V_MAXWINDOW];
static XSizeHints win[V_MAXWINDOW];
static unsigned long foreground[V_MAXWINDOW],
    background[V_MAXWINDOW], nanim[V_MAXWINDOW];
static GC gc[V_MAXWINDOW];
static Pixmap pixmap[V_MAXWINDOW];
static unsigned int border_width[V_MAXWINDOW],
    color_depth[V_MAXWINDOW], mask[V_MAXWINDOW],
    xpm_counter[V_MAXWINDOW];
static Colormap colormap[V_MAXWINDOW];
static XColor color[V_MAXWINDOW][V_MAXCOLOR];
static int x[V_MAXWINDOW], y[V_MAXWINDOW],
    px[V_MAXWINDOW], py[V_MAXWINDOW],
    lx[V_MAXWINDOW], ly[V_MAXWINDOW];
static double unit[V_MAXWINDOW], w[V_MAXWINDOW][2],
    A[V_MAXWINDOW][2][2], ws[V_MAXWINDOW][2],
    rate[V_MAXWINDOW], timespent[V_MAXWINDOW],
    factor[V_MAXWINDOW], dws[V_MAXWINDOW][2];
static const char *Vcolorname[V_MAXCOLOR]=
{"black", "red", "green", "blue", 
 "cyan", "magenta", "yellow", "white"};
/* internal functions */
static void thread_start (void *iw_pointer);
static void Animate (int iw);
static Bool treatevent (int iw, XEvent *e);
static void rw2s (int iw, double rw[2], double s[2]);
static Bool s2screen (int iw, double s[2]);
static void setfg (int iw, int cid);
static void setLA (int iw, int cid);
static Bool box_clip_line
(double x0,double y0,double width,double height,double xx[4]);
static void Draw_LINE (int iw, int cid, int xx[4]);
static void Render_LINE (int iw, int n, VLINE gp[]);
static Bool window_clip_circle (int iw, int x, int y, int r);
static void Render_POINT (int iw, int n, VPOINT gp[]);
static void Render_CIRCLE(int iw, int n, VCIRCLE gp[]);
static void signal_handler (int signal_number);
/** this program: internal use only **/


/* Animators are not allowed to render when */
/* the OG is being modified by main thread. */
void VLock()
{
    LockOGL = True;
    return;
} /* end VLock() */


/* Unlock when done and clean the slates */
void VUnLock()
{
    int i;
    LockOGL = False;
    for (i=0; i<V_MAXWINDOW; i++)
	OGLRendered[i] = False;
    return;
} /* end VUnLock() */


void VSetPBC (int iw, Bool b)
{
    PBC[iw] = b;
    return;
} /* end PBC() */


/* Entry-point of the animator threads. */
/* Display is a connection, thus can only */
/* be used by a single thread at a time */
void thread_start (void *iw_pointer)
{
    int i, iw=*((int *)iw_pointer);
    /* connect to the X server */
    display[iw] = XOpenDisplay(&display_address[iw][0]);
    if (display[iw] == NULL)
    {
	printf ("Cannot open display \"%s\", please xhost+.\n",
		&display_address[iw][0]);
	exit(1);
    }
    /* get default screen */
    screen[iw] = DefaultScreen (display[iw]);
    /* get the current color map setting */
    colormap[iw] = DefaultColormap (display[iw], screen[iw]);
    /* allocate the named colors */
    for (i=0; i<V_MAXCOLOR; i++)
	if (XAllocNamedColor(display[iw], colormap[iw],
			     Vcolorname[i], &color[iw][i],
			     &color[iw][i])==0)
	    printf ("color #%d(\"%s\") is unavailable on %s.\n",
		    &display_address[iw][0]);
    /* black and white on current server */
    background[iw] =
	BlackPixel (display[iw], screen[iw]);
    foreground[iw] =
	WhitePixel (display[iw], screen[iw]);
    /* root window */
    root[iw] = DefaultRootWindow (display[iw]);
    windows[iw] = XCreateSimpleWindow
	( display[iw], root[iw], 100, 100,
	  win[iw].width+1, win[iw].height+1,
	  border_width[iw], foreground[iw], background[iw] );
    if ( (void *)windows[iw] == NULL )
    {
	printf ("Cannot open window %d on \"%s\"\n",
		iw, &display_address[iw][0]);
	exit(1);
    }
    XSetStandardProperties
	( display[iw], windows[iw], &title[iw][0],
	  &title[iw][0], None, NULL, 0, &win[iw] );
    /* event filter */
    XSelectInput ( display[iw], windows[iw],
		   ButtonPressMask |
		   ButtonReleaseMask |
		   Button1MotionMask |
		   KeyPressMask |
		   ExposureMask );
    /* pop this window up on the screen */
    XMapRaised (display[iw], windows[iw]);
    XGetGeometry ( display[iw], windows[iw],
		   &root[iw], &win[iw].x, &win[iw].y,
		   (unsigned *) &win[iw].width,
		   (unsigned *) &win[iw].height,
		   &border_width[iw], &color_depth[iw] );
    win[iw].width--; win[iw].height--;
    /* pixmap instead of window for back-buffer drawing */
    pixmap[iw] = XCreatePixmap
	( display[iw], root[iw], win[iw].width,
	  win[iw].height, color_depth[iw] );
    gc[iw] = XCreateGC (display[iw], pixmap[iw], 0, 0);
    Animate (iw);
}  /* end thread_start() */


/* Sets foreground color: avoid     */
/* redundant requests to the server */
void setfg (int iw, int cid)
{
    static int lastcid[V_MAXWINDOW]={0};
    cid = abs(cid)-1;
    if ( lastcid[iw] != cid )
    {
	XSetForeground(display[iw], gc[iw],
		       color[iw][cid].pixel);
	lastcid[iw] = cid;
    }
    return;
} /* end setfg() */


/* Sets line attribute: >0 solid, <0 dash */
void setLA (int iw, int cid)
{
    static int lastLA[V_MAXWINDOW]={0};
    if ( lastLA[iw] * cid <= 0 )
    {
	if ( cid > 0 )
	    XSetLineAttributes (display[iw], gc[iw],
				1, LineSolid,
				CapButt, JoinMiter);
	else if ( cid < 0 )
	    XSetLineAttributes (display[iw], gc[iw],
				1, LineOnOffDash,
				CapButt, JoinMiter);
	else
	{
	    printf ("setLA(): cid = 0 illegal.\n");
	    exit(1);
	}
	lastLA[iw] = cid;
    }
    return;
} /* end setLA() */


#define inside_box(width,height,x,y) \
(((x)*(x-(width))<=V_TINY)&&((y)*(y-(height))<=V_TINY))
/* clip line (xx[0],xx[1])-(xx[2],xx[3]) */
/* by rectangle (x0,y0)+(width,height).  */
Bool box_clip_line (double x0, double y0, double width,
		    double height, double xx[4])
{
    int i, j, m, n;
    double dir[2], c[6], cc, dd;
    Bool A, B;
    A = inside_box(width,height,xx[0]-x0,xx[1]-y0);
    B = inside_box(width,height,xx[2]-x0,xx[3]-y0);
    if (A&&B) return (True);
    dir[0] = xx[2]-xx[0]; dir[1] = xx[3]-xx[1];
    /* distances of vertices to the line */
    c[0] = (x0-xx[0])*(-dir[1])+(y0-xx[1])*dir[0];
    c[1] = (x0+width-xx[0])*(-dir[1])+(y0-xx[1])*dir[0];
    c[2] = (x0-xx[0])*(-dir[1])+(y0+height-xx[1])*dir[0];
    c[3] = (x0+width-xx[0])*(-dir[1])+(y0+height-xx[1])*dir[0];
    /* see if the segment lies within the window */
    if ((c[0]*c[1]>0)&&(c[0]*c[2]>0)&&(c[0]*c[3]>0))
	return (False);
    dd = sqrt(dir[0]*dir[0]+dir[1]*dir[1]);
    if (dd==0) return (False);
    dir[0] /= dd; dir[1] /= dd;
    if ( fabs(xx[2]-xx[0]) < V_TINY )
    {
	c[2] = (y0+height-xx[1])*dir[1];
	c[3] = (y0-xx[1])*dir[1];
	m = 4;
    }
    else if ( fabs(xx[3]-xx[1]) < V_TINY )
    {
	c[2] = (x0-xx[0])*dir[0];
	c[3] = (x0+width-xx[0])*dir[0];
	m = 4;
    }
    else
    {
	cc = 1+dir[1]*dir[1]/dir[0]/dir[0];
	c[2] = (x0-xx[0])*dir[0]*cc;
	c[3] = (x0+width-xx[0])*dir[0]*cc;
	cc = 1+dir[0]*dir[0]/dir[1]/dir[1];
	c[4] = (y0+height-xx[1])*dir[1]*cc;
	c[5] = (y0-xx[1])*dir[1]*cc;
	m = 6;
    }
    for (n=i=2; i<m; i++)
	if ((c[i]<dd+100*V_TINY)&&(c[i]>-100*V_TINY)&&
	    inside_box(width,height,xx[0]+c[i]*dir[0]-x0,
		       xx[1]+c[i]*dir[1]-y0))
	    c[n++] = c[i];
    if (A)
    {  
	xx[2] = xx[0] + c[2]*dir[0];
	xx[3] = xx[1] + c[2]*dir[1];
    }
    else if (B)
    {
	xx[0] += c[2]*dir[0];
	xx[1] += c[2]*dir[1];
    }
    else
    {
	if (n!=4) return(False);
	if (c[2]>c[3]) {cc=c[3];dd=c[2];}
	else {cc=c[2];dd=c[3];}
	xx[2] = xx[0] + dd*dir[0];
	xx[3] = xx[1] + dd*dir[1];
	xx[0] += cc*dir[0];
	xx[1] += cc*dir[1];
    }
    return (True);
} /* end windowclip() */


/* Draw a line on the window with automatic window clipping */
#define TEST_LINE_CLIPPING
void Draw_LINE (int iw, int cid, int x[4])
{
    double xx[4];
    xx[0]=x[0]; xx[1]=x[1]; xx[2]=x[2]; xx[3]=x[3];
    if ( box_clip_line(0,0,win[iw].width,win[iw].height,xx) )
    {
	setfg (iw, cid); setLA (iw, cid);
	XDrawLine (display[iw], pixmap[iw], gc[iw],
		   rint(xx[0]), rint(xx[1]), rint(xx[2]),
		   rint(xx[3]));
#ifdef TEST_LINE_CLIPPING
	if ( (xx[0]!=x[0]) || (xx[1]!=x[1]) )
	{
	    setfg (iw, V_RED); setLA(iw, 1);
	    XDrawArc (display[iw], pixmap[iw], gc[iw],
		      rint(xx[0])-5, rint(xx[1])-5,
		      10, 10, 0, 360*64);
	}
	if ( (xx[2]!=x[2]) || (xx[3]!=x[3]) )
	{
	    setfg (iw, V_RED); setLA(iw, 1);
	    XDrawArc (display[iw], pixmap[iw], gc[iw],
		      rint(xx[2])-5, rint(xx[3])-5,
		      10, 10, 0, 360*64);
	}
#endif
    }
    return;
} /* end Draw_LINE() */


/* convert reduced rw[] coordinates to s[] */
void rw2s (int iw, double rw[2], double s[2])
{
    double cc, HI[2][2];
    cc = H[0][0]*H[1][1]-H[0][1]*H[1][0];
    HI[0][0] =  H[1][1]/cc;
    HI[0][1] = -H[0][1]/cc;
    HI[1][0] = -H[1][0]/cc;
    HI[1][1] =  H[0][0]/cc;
    s[0] = unit[iw]*(rw[0]*HI[0][0]+rw[1]*HI[1][0]);
    s[1] = unit[iw]*(rw[0]*HI[0][1]+rw[1]*HI[1][1]);
    if ( PBC[iw] )
    {
	while (s[0]<0) s[0]++;
	while (s[0]>1) s[0]--;
	while (s[1]<0) s[1]++;
	while (s[1]>1) s[1]--;
	rw[0]=(s[0]*H[0][0]+s[1]*H[1][0])/unit[iw];
	rw[1]=(s[0]*H[0][1]+s[1]*H[1][1])/unit[iw];
    }
    return;
} /* end rw2s() */


/* s -> X, only one copy of the objects about ws[]+-0.5 */
Bool s2screen (int iw, double s[2])
{
    double sc[2], sr[2];
    dws[iw][0] = s[0]-ws[iw][0];
    dws[iw][1] = s[1]-ws[iw][1];
    if ( PBC[iw] )
    {
	while (dws[iw][0]<-0.5) dws[iw][0]++;
	while (dws[iw][0]>0.5)  dws[iw][0]--;
	while (dws[iw][1]<-0.5) dws[iw][1]++;
	while (dws[iw][1]>0.5)  dws[iw][1]--;
    }
    sc[0] = (dws[iw][0]*H[0][0]+dws[iw][1]*H[1][0])/unit[iw];
    sc[1] = (dws[iw][0]*H[0][1]+dws[iw][1]*H[1][1])/unit[iw];
    /* readings in window axes */
    sr[0] = A[iw][0][0]*sc[0]+A[iw][0][1]*sc[1];
    sr[1] = A[iw][1][0]*sc[0]+A[iw][1][1]*sc[1];
    x[iw] = rint(win[iw].width/2.+sr[0]*V_RESOLUTION);
    y[iw] = rint(win[iw].height/2.-sr[1]*V_RESOLUTION);
    return(inside_box(win[iw].width,win[iw].height,x[iw],y[iw]));
} /* end s2screen() */


/* activated by Up/Down/Left/Right events */
void translate_window (int iw, int i, double delta)
{
    if ( PBC[iw] )
    {
	w[iw][0] = (ws[iw][0]*H[0][0]+
		    ws[iw][1]*H[1][0])/unit[iw];
	w[iw][1] = (ws[iw][0]*H[0][1]+
		    ws[iw][1]*H[1][1])/unit[iw];
    }
    w[iw][0] += delta * A[iw][i][0];
    w[iw][1] += delta * A[iw][i][1];
    rw2s (iw, &w[iw][0], &ws[iw][0]);
    return;
} /* end translate_window() */


#define min_motion 3
void rotate_window (int iw, int to_x, int to_y)
{
    int i, j;
    double a[2], b[2], ca[2], cb[2], g[2], cc;
    if ((to_x-lx[iw])*(to_x-lx[iw]) +
	(to_y-ly[iw])*(to_y-ly[iw]) <
	min_motion*min_motion) return;
    /* stuffs seem to rotate from a[] */
    a[0] = lx[iw]-win[iw].width/2.;
    a[1] = -ly[iw]+win[iw].height/2.;
    cc = sqrt(a[0]*a[0]+a[1]*a[1]);
    if ( cc<=min_motion ) return;
    a[0] /= cc; a[1] /= cc;
    /* to b[] in the viewport, */
    b[0] = to_x-win[iw].width/2.;
    b[1] = -to_y+win[iw].height/2.;
    cc = sqrt(b[0]*b[0]+b[1]*b[1]);
    if ( cc<=min_motion ) return;
    b[0] /= cc; b[1] /= cc;
    /* equivalent to rotate the VIEWPORT from b to a */
    ca[0] = -a[1]; ca[1] = a[0];
    cb[0] = -b[1]; cb[1] = b[0];
    g[0] = A[iw][0][0]*b[0] +A[iw][0][1]*b[1];
    g[1] = A[iw][0][0]*cb[0]+A[iw][0][1]*cb[1];
    /* b->a, cb->ca */
    A[iw][0][0] = g[0]*a[0]+g[1]*ca[0];
    A[iw][0][1] = g[0]*a[1]+g[1]*ca[1];
    A[iw][1][0] = -A[iw][0][1];
    A[iw][1][1] = A[iw][0][0];
    /* save pointer motion */
    lx[iw] = to_x; ly[iw] = to_y;
    return;
} /* end rotate_window() */


/* PBC: render a physical bonding between the two points */
void Render_LINE (int iw, int n, VLINE gp[])
{
    int i, xx[4], zz[4];
    double sw[4], ss[4], ds[2],	s[4], sc[2], dx[2];
    for (i=0; i<n; i++)
	if ( gp[i].cid!=0 )
	{ /* start and end point position */
	    s2screen (iw, &gp[i].s[0]);
	    xx[0] = x[iw]; xx[1] = y[iw];
	    sw[0] = dws[iw][0]; sw[1] = dws[iw][1];
	    s2screen (iw, &gp[i].s[2]);
	    xx[2] = x[iw]; xx[3] = y[iw];
	    sw[2] = dws[iw][0]; sw[3] = dws[iw][1];
	    if (PBC[iw])
	    {  /* actual bonding direction */
		ds[0] = gp[i].s[2]-gp[i].s[0];
		ds[1] = gp[i].s[3]-gp[i].s[1];
		while (ds[0]>0.5)  ds[0]--;
		while (ds[0]<-0.5) ds[0]++;
		while (ds[1]>0.5)  ds[1]--;
		while (ds[1]<-0.5) ds[1]++;
		ss[0] = sw[0]; ss[1] = sw[1];
		ss[2] = ss[0]+ds[0]; ss[3] = ss[1]+ds[1];
		/* clip it by +-0.5 */
		box_clip_line (-0.5,-0.5,1,1,ss);
		sc[0] = (ss[2]-sw[0])*H[0][0]+(ss[3]-sw[1])*H[1][0];
		sc[1] = (ss[2]-sw[0])*H[0][1]+(ss[3]-sw[1])*H[1][1];
		dx[0] = rint((sc[0]*A[iw][0][0]+sc[1]*A[iw][0][1])/
			     unit[iw]*V_RESOLUTION);
		dx[1] = rint((sc[0]*A[iw][1][0]+sc[1]*A[iw][1][1])/
			     unit[iw]*V_RESOLUTION);
		zz[0]=xx[0]; zz[1]=xx[1];
		zz[2]=zz[0]+rint(dx[0]); zz[3]=zz[1]-rint(dx[1]);
		Draw_LINE (iw, gp[i].cid, zz);
		if ((abs(zz[2]-xx[2])>1)||(abs(zz[3]-xx[3])>1))
		{
		    ss[0] = sw[2]; ss[1] = sw[3];
		    ss[2] = ss[0]-ds[0]; ss[3] = ss[1]-ds[1];
		    box_clip_line (-0.5,-0.5,1,1,ss);
		    sc[0] = (ss[2]-sw[2])*H[0][0]+(ss[3]-sw[3])*H[1][0];
		    sc[1] = (ss[2]-sw[2])*H[0][1]+(ss[3]-sw[3])*H[1][1];
		    dx[0] = rint((sc[0]*A[iw][0][0]+sc[1]*A[iw][0][1])/
				 unit[iw]*V_RESOLUTION);
		    dx[1] = rint((sc[0]*A[iw][1][0]+sc[1]*A[iw][1][1])/
				 unit[iw]*V_RESOLUTION);
		    zz[0]=xx[2]; zz[1]=xx[3];
		    zz[2]=zz[0]+rint(dx[0]); zz[3]=zz[1]-rint(dx[1]);
		    Draw_LINE (iw, gp[i].cid, zz);
		}
	    }
	    else
		Draw_LINE (iw, gp[i].cid, xx);
	}
    return;
} /* end Render_LINE() */


Bool window_clip_circle (int iw, int x, int y, int r)
{
    return(inside_box(win[iw].width,win[iw].height,x-r,y-r) ||
	   inside_box(win[iw].width,win[iw].height,x-r,y+r) ||
	   inside_box(win[iw].width,win[iw].height,x+r,y-r) ||
	   inside_box(win[iw].width,win[iw].height,x+r,y+r) );
} /* end window_clip_circle() */


/* Draw a circle on the window with automatic clipping */
void Draw_CIRCLE
(int iw, int x, int y, int a, int cid)
{
    setfg (iw, cid);
    if ((a==1) &&
	inside_box(win[iw].width,win[iw].height,x,y))
	XDrawPoint(display[iw], pixmap[iw],
		   gc[iw], x, y);
    else if ((a==2)&&window_clip_circle(iw,x,y,1))
    {
	XDrawPoint(display[iw], pixmap[iw],
		   gc[iw], x+1, y);
	XDrawPoint(display[iw], pixmap[iw],
		   gc[iw], x-1, y);
	XDrawPoint(display[iw], pixmap[iw],
		   gc[iw], x, y+1);
	XDrawPoint(display[iw], pixmap[iw],
		   gc[iw], x, y-1);
	if (cid > 0)
	    XDrawPoint(display[iw], pixmap[iw],
		       gc[iw], x, y);
    }
    else if (window_clip_circle(iw,x,y,a))
    { /* draw solid circle */
	setLA (iw, 1);
	if (cid > 0)
	    XFillArc(display[iw], pixmap[iw],
		     gc[iw], x-a, y-a,
		     a*2, a*2, 0, 360*64);
	else
	    XDrawArc(display[iw], pixmap[iw],
		     gc[iw], x-a, y-a,
		     a*2, a*2, 0, 360*64);
    }
    return;
}
/* end Draw_CIRCLE() */

	    
void Render_POINT (int iw, int n, VPOINT gp[])
{
    int i; VLINE line[1];
    for (i=0; i<n; i++)
	if (gp[i].lcid != 0)
	{
	    line[0].s[0] = gp[i].s[0];
	    line[0].s[1] = gp[i].s[1];
	    line[0].s[2] = gp[(i+1)%n].s[0];
	    line[0].s[3] = gp[(i+1)%n].s[1]; 
	    line[0].cid = gp[i].lcid;
	    Render_LINE (iw, 1, line);
	}
    for (i=0; i<n; i++)
	if ( gp[i].cid != 0 )
	{
	    s2screen(iw, gp[i].s);
	    Draw_CIRCLE (iw, x[iw], y[iw],
			 gp[i].size, gp[i].cid);
	}
    return;
} /* end Render_POINT() */


void Render_CIRCLE (int iw, int n, VCIRCLE gp[])
{
    int i, a; 
    for (i=0; i<n; i++)
    {
	s2screen(iw, gp[i].s);
	a = rint(gp[i].radius/unit[iw]*V_RESOLUTION);
	if (a==0) a=1;
	Draw_CIRCLE (iw, x[iw], y[iw], a, gp[i].cid);
    }
    return;
} /* end Render_CIRCLE() */


/* Draw on created window, then sleep for a while; */
/* handle events first if the queue is not empty.  */
void Animate (int iw)
{
    int i;
    struct OGL *p;
    Bool nontrivial_event;
    XEvent event;
    struct timeval tp;
    double inittime, rendertime=0;
    VLINE line[4];
    while (1)
    {
	inittime=0;
	nontrivial_event = False;
	/* handle events accumulated in the queue */
	while ( XPending(display[iw]) )
	{
	    if (inittime==0)
	    {
		gettimeofday (&tp, NULL);
		inittime = tp.tv_sec+0.000001*tp.tv_usec;
	    }
	    XNextEvent (display[iw], &event);
	    nontrivial_event = nontrivial_event ||
		treatevent (iw, &event);
	}
	if ( !active[iw] )
	{
	    XFreeColormap(display[iw], colormap[iw]);
	    XDestroyWindow(display[iw], windows[iw]);
	    XCloseDisplay(display[iw]);
	    printf ("\nWindow #%d closed on \"%s\",\n",
		    iw, &display_address[iw][0]);
	    printf ("%ld frames rendered, avg %.4f frames/s.\n\n",
		    nanim[iw], nanim[iw]/timespent[iw]);
	    pthread_exit((void *)NULL);
	}
	if ( nontrivial_event || 
	     ((!LockOGL)&&(!OGLRendered[iw])) )
	{
	    if (inittime==0)
	    {
		gettimeofday (&tp, NULL);
		inittime = tp.tv_sec+0.000001*tp.tv_usec;
	    }
	    /* PBC: ws[] stays constant; otherwise w[] */
	    if ( !PBC[iw] ) rw2s (iw, &w[iw][0], &ws[iw][0]);
	    setfg (iw, V_BLACK);
	    XFillRectangle (display[iw], pixmap[iw],
			    gc[iw], 0, 0, win[iw].width,
			    win[iw].height);
	    if ( PBC[iw] )
	    {	/* draw a bounding box that shows ws[]+-0.5  */
		line[0].s[0]=ws[iw][0]-0.5; line[0].s[1]=ws[iw][1]-0.5;
		line[0].s[2]=ws[iw][0]+0.5; line[0].s[3]=ws[iw][1]-0.5;
		line[1].s[0]=ws[iw][0]+0.5; line[1].s[1]=ws[iw][1]-0.5;
		line[1].s[2]=ws[iw][0]+0.5; line[1].s[3]=ws[iw][1]+0.5;
		line[2].s[0]=ws[iw][0]+0.5; line[2].s[1]=ws[iw][1]+0.5;
		line[2].s[2]=ws[iw][0]-0.5; line[2].s[3]=ws[iw][1]+0.5;
		line[3].s[0]=ws[iw][0]-0.5; line[3].s[1]=ws[iw][1]+0.5;
		line[3].s[2]=ws[iw][0]-0.5; line[3].s[3]=ws[iw][1]-0.5;
		line[0].cid=line[1].cid=line[2].cid=line[3].cid=-V_WHITE;
 		PBC[iw]=False; Render_LINE (iw, 4, line); PBC[iw]=True;
	    }
	    for (p=oglpool; p->next!=NULL; p=p->next)
		switch (p->next->obj_type)
		{
		case V_POINT:
		    Render_POINT(iw, p->next->n,
				 (VPOINT*)(p->next->gp));
		    break;
		case V_LINE:
		    Render_LINE(iw, p->next->n,
				(VLINE*)(p->next->gp));
		    break;
		case V_CIRCLE:
		    Render_CIRCLE(iw, p->next->n,
				  (VCIRCLE*)(p->next->gp));
		    break;
		default:
		    printf ("obj_type %d does not exist.\n", 
			    p->next->obj_type);
		    exit(1);
		}
	    XCopyArea (display[iw], pixmap[iw], windows[iw],
		       gc[iw], 0, 0, win[iw].width,
		       win[iw].height, 0, 0);
	    /* synchronize with the server without  */
	    /* discarding events in the event queue */
	    XSync (display[iw], False);
	    OGLRendered[iw] = True;
	    nanim[iw]++;
	    /* dynamic tuning of refresh rate */
	    gettimeofday (&tp, NULL);
	    rendertime = tp.tv_sec+0.000001*tp.tv_usec-inittime;
	    timespent[iw] +=
		(rendertime>1./rate[iw])?rendertime:1./rate[iw];
	}
	if ( 1./rate[iw] > rendertime )
	    waitfor( 1./rate[iw] - rendertime );
    }
} /* end Animate() */


/* capture the screen in ASCII xpm format */
int capture_xpm (int iw)
{
    char filename[2*V_MAX_STRLEN], *p, *q;
    sprintf (filename, "%s_%d.xpm", &title[iw][0],
	     xpm_counter[iw]++);
    /* fill white space by underline */
    for (q=filename; (*q!=(char)0); q++)
	if ((*q==' ')||(*q=='\t')) *q = '_';
    printf("\nSave screen %d on (default=\"%s\"): ",
	   iw, filename);
    for (p=q; p<filename+2*V_MAX_STRLEN-5; p++)
	if ((*p=(char)getc(stdin))=='\n')
	    break;
    if (p==q) q=filename;
    *p = (char)0;
    /* add file suffix if without */
    if (strcasecmp(p-4,".xpm")) sprintf(p,".xpm");
    else p=p-4;
    if ( freetowrite(q) )
    {
	XpmWriteFileFromPixmap
	    (display[iw], q, pixmap[iw], NULL, NULL);
	printf ("saved on \"%s\".\n", q);
    }
    printf ("\n");
    return (xpm_counter[iw]);
} /* end capture_xpm() */


void print_status (int iw)
{
    printf("================ Status of window #%d ===============\n",iw);
    printf("One render world unit = %f A, in rw frame:\n\n", unit[iw]);
    printf("  H =  | %.5f %.5f |\n", H[0][0]/unit[iw],H[0][1]/unit[iw]);
    printf("[unit] | %.5f %.5f |\n\n", H[1][0]/unit[iw],H[1][1]/unit[iw]);
    if (PBC[iw])
	printf("Viewport center position ws = [ %.5f %.5f ]\n",
	       ws[iw][0], ws[iw][1]);
    else
	printf("Viewport center position w = [ %.5f %.5f ] unit\n",
	       w[iw][0],  w[iw][1]);
    printf("x = [ %.5f %.5f ] * %.5f, %d pixels\n",
	   A[iw][0][0], A[iw][0][1],
	   (double)win[iw].width/V_RESOLUTION, win[iw].width);
    printf("y = [ %.5f %.5f ] * %.5f, %d pixels\n",
	   A[iw][1][0], A[iw][1][1],
	   (double)win[iw].height/V_RESOLUTION, win[iw].height);
    printf("PBC = %s,  factor of change = %.2f\n\n",
	   PBC[iw]?"TRUE":"FALSE",factor[iw]);
    printf("Window origin=[%d %d], color depth=%d\n",
	   win[iw].x, win[iw].y, color_depth[iw]);
    printf("pointer XY: this=[%d %d] last=[%d %d],\n\n",
	   px[iw], py[iw], lx[iw], ly[iw]);
    printf("This animator has lived for approx. %.1f seconds,\n",
	   timespent[iw]);
    printf ("frames rendered = %ld, designed refresh rate = %.1f,\n",
	    nanim[iw], rate[iw]);
    printf("average refresh rate till now = %.1f frames/s.\n",
	   nanim[iw]/timespent[iw]);
    printf("=====================================================\n");
    return;
} /* print_status() */


void print_help (int iw)
{
    printf("*****************************************************\n");
    printf("List of Actions (window #%d):\n\n",iw);
    printf("Use mouse to change orientation of viewport\n\n");
    printf("Up/Down/Right/Left: shift view-port\n");
    printf("PageUp/PageDown: de/increase lengthscale of viewport\n");
    printf("0 to 9: toggle rate of change\n");
    printf("<1>0.0005 <2>0.001 <3>0.002 <4>0.005 <5>0.01\n");
    printf("<6>0.02   <7>0.05  <8>0.1   <9>0.25  <0>default\n\n");
    printf("F1: help\n");
    printf("F2: print out status of this window\n");
    printf("F3: clone this window\n");
    printf("F4: generate a default window\n");
    printf("F5: restore collinear axes\n");
    printf("F6: dump screen-shot to .xpm file\n");
    printf("F9: toggle PBC\n");
    printf("ESC: close this window\n");
    printf("q:   close all windows\n\n");
    printf("If no window exists, create a new one by\n");
    printf("%% kill -%d %d\n", V_SIGNAL, (int)master_pid);
    printf("****************************************************\n");
    return;
} /* end print_help() */


/* Event-handler of the Animator */
Bool treatevent (int iw, XEvent *e)
{
    static long last_button_press_time[V_MAXWINDOW]
	= {0};
    int a, b; Bool c;
    XSizeHints newhint;
    Window root_return, child_return;
    c = XQueryPointer (display[iw], windows[iw],
		       &root_return, &child_return,
		       &a, &b, &px[iw],
		       &py[iw], &mask[iw]);
    switch ( e->type )
    {
    case ButtonPress:
	if ( e->xbutton.time - last_button_press_time[iw]
	     < V_DEFAULT_DBLE_CLICK_IN_MS )
	{  /* double click event */
	    translate_window(iw,0,(px[iw]-win[iw].width/2.)/V_RESOLUTION); 
	    translate_window(iw,1,(-py[iw]+win[iw].height/2.)/V_RESOLUTION);
	    XWarpPointer (display[iw], windows[iw], None, 0, 0,
			  0, 0, -px[iw]+win[iw].width/2,
			  -py[iw]+win[iw].height/2);
	    last_button_press_time[iw] = -V_HUGE;
	    return (True);
	}
	else
	{
	    lx[iw]=px[iw]; ly[iw]=py[iw];
	    last_button_press_time[iw] = e->xbutton.time;
	    return (False);
	}
    case ButtonRelease:
    case MotionNotify:
	rotate_window (iw, px[iw], py[iw]);
        return (True);
    case Expose:  
	XGetGeometry (display[iw], windows[iw],
		      &root[iw], &newhint.x, &newhint.y,
		      (unsigned *) &newhint.width,
		      (unsigned *) &newhint.height,
		      &border_width[iw], &color_depth[iw] );
	win[iw].width--; win[iw].height--;
	win[iw].x = newhint.x; win[iw].y = newhint.y;
	if ( (newhint.width!=win[iw].width) ||
	     (newhint.height!=win[iw].height) )
	{   /* the window has been resized */
	    /* old pixmap cannot be used   */
	    XFreeGC (display[iw], gc[iw]);
	    XFreePixmap (display[iw], pixmap[iw]);
	    win[iw].width = newhint.width;
	    win[iw].height = newhint.height;
	    pixmap[iw] = XCreatePixmap
		( display[iw], root[iw], win[iw].width,
		  win[iw].height, color_depth[iw] );
	    gc[iw] = XCreateGC(display[iw],pixmap[iw],0,0);
	}
	return (True);
    case KeyPress:
	if (!c) return (False);
        switch (XKeycodeToKeysym
		(display[iw], e->xkey.keycode, 0))
        {
        case XK_F1: print_help(iw); return (False);
	case XK_F2: print_status(iw); return (False);
        case XK_F3:
	    translate_window(iw,0,0);
	    VAddWindow (display_address[iw], 
			"V_DEFAULT", H, unit[iw],
			w[iw][0], w[iw][1],
			A[iw][0][0], A[iw][0][1], 
			(double)win[iw].width/V_RESOLUTION, 
			(double)win[iw].height/V_RESOLUTION, 
			rate[iw]);
	    return (False);
        case XK_F4: VAddDefaultWindow(H); return (False);
        case XK_F5: A[iw][0][0]=1; A[iw][0][1]=0;
	    A[iw][1][0]=0; A[iw][1][1]=1; return (True);
        case XK_F6: capture_xpm(iw); return (False);
        case XK_F9: VSetPBC(iw,!PBC[iw]); return (True);
        case XK_Escape: VCloseWindow(iw); return (False);
        case XK_q: VCloseAllWindows(); return (False);
        case XK_Left: translate_window(iw,0,factor[iw]);return(True);
        case XK_Right: translate_window(iw,0,-factor[iw]);return(True);
        case XK_Down: translate_window(iw,1,factor[iw]); return(True);
        case XK_Up: translate_window(iw,1,-factor[iw]); return(True);
        case XK_Page_Up: unit[iw] /= (1+factor[iw]);
	    if ( !PBC[iw] )
	    {
		w[iw][0]*=(1+factor[iw]);
		w[iw][1]*=(1+factor[iw]);
	    }
	    return(True);
        case XK_Page_Down: unit[iw] *= (1+factor[iw]);
	    if ( !PBC[iw] )
	    {
		w[iw][0]/=(1+factor[iw]);
		w[iw][1]/=(1+factor[iw]);
	    }
	    return(True);
	case XK_1: factor[iw]=0.0005; return(False);
	case XK_2: factor[iw]=0.001; return(False);
	case XK_3: factor[iw]=0.002; return(False);
	case XK_4: factor[iw]=0.005; return(False);
	case XK_5: factor[iw]=0.01; return(False);
	case XK_6: factor[iw]=0.02; return(False);
	case XK_7: factor[iw]=0.05; return(False);
	case XK_8: factor[iw]=0.1; return(False);
	case XK_9: factor[iw]=0.25; return(False);
	case XK_0: factor[iw]=DEFAULT_FACTOR; return(False);
        default: return (False);
        }
    default: return (False);
    }
} /* end treatevent() */


void signal_handler (int signal_number)
{
    if (signal_number == V_SIGNAL)
    {
	VAddDefaultWindow(H);
	/* because it is automatically */
	signal(V_SIGNAL, &signal_handler);
	/* reset after being used once */
    }
    return;
} /* signal_handler() */


void VSignIn (volatile double h[2][2])
{
    static Bool first_entry = True;
    if (first_entry)
    {
	H = h;
	master_pid = getpid();
	signal (V_SIGNAL, &signal_handler);
	printf("\n=========================================\n");
	printf("VSignIn(): if no window exists, create a\n");
	printf("new one by %% kill -%d %d\n", V_SIGNAL,
	       (int)master_pid);
	printf("=========================================\n\n");
    }
    return;
} /* end VSignIn() */


int VAddWindow (char address[], char vtitle[],
		volatile double h[2][2],
		double vunit,
		double vwx, double vwy,
		double vxx, double vxy,
		double vwidth, double vheight,
		double vrefreshrate)
{
    static Bool first_entry = True;
    static int iw; 
    double cc;
    pthread_t tid;
    if (first_entry)
    {
	VSignIn (h);
	first_entry = False;
    }
    else
	if ( H!=h )
	{
	    printf ("Fatal: matrix H has been moved.\n");
	    exit(1);
	}
    /* find an unoccupied slot */
    for (iw=0;
	 (iw<V_MAXWINDOW) && active[iw];
	 iw++);
    if ( iw==V_MAXWINDOW )
    {
	printf ("V_MAXWINDOW = %d reached (see \"v.h\").\n",
		V_MAXWINDOW);
	return (0);
    }
    /* check incoming string lengths */
    if ( (strlen(address) >= V_MAX_STRLEN) ||
	 (strlen(vtitle)  >= V_MAX_STRLEN) )
    {
	printf ("V_MAX_STRLEN = %d reached (see \"v.h\").\n",
		V_MAX_STRLEN);
	exit(1);
    }
    /* store the TCP/IP X connection address */
    strcpy (&display_address[iw][0], address);
    if (!strcasecmp(&display_address[iw][0], "V_DEFAULT"))
	strcpy (&display_address[iw][0], getenv("DISPLAY"));
    /* store the window title name */
    strcpy (&title[iw][0], vtitle);
    if (!strcasecmp(&title[iw][0], "V_DEFAULT"))
	sprintf (&title[iw][0], "win %d", iw);
    /* how much rs length is 1 render world (rw) unit */
    unit[iw] = vunit;
    /* where to put the window */
    w[iw][0] = vwx; w[iw][1] = vwy;
    rw2s (iw, &w[iw][0], &ws[iw][0]);
    /* what is the window x-axes in rw */
    cc = sqrt(vxx*vxx+vxy*vxy);
    A[iw][0][0] = vxx / cc;
    A[iw][0][1] = vxy / cc;
    A[iw][1][0] = -A[iw][0][1];
    A[iw][1][1] = A[iw][0][0];
    /* set X properties */
    win[iw].width = ceil(vwidth*V_RESOLUTION);
    win[iw].height = ceil(vheight*V_RESOLUTION);
    win[iw].flags = PSize;
    /* factor of change */
    factor[iw] = DEFAULT_FACTOR;
    /* pictures per second */
    rate[iw] = key_verify(double,vrefreshrate,V_DEFAULT)?
	V_DEFAULT_REFRESHRATE:vrefreshrate;
    active[iw] = True;
    PBC[iw] = True;
    xpm_counter[iw] = 0;
    nanim[iw]=1; timespent[iw]=1/rate[iw];
    /* spawn a thread to animate and handle events */
    pthread_create (&tid, NULL, (void *(*)(void *))
		    thread_start, (void *)(&iw));
    return (iw);
} /* end VAddWindow() */


int VAddDefaultWindow (volatile double h[2][2])
{
    double det, length;
    det = h[0][0]*h[1][1]-h[0][1]*h[1][0];
    length = sqrt(fabs(det));
    return(VAddWindow("V_DEFAULT", /* DISPLAY as xhost */
		      "V_DEFAULT", /* win title name */
		      h,           /* metric of rs   */
		      length,      /* rs->rw unit cov */
		      /* viewport at center */
		      0.5*(h[0][0]+h[1][0])/length, 
		      0.5*(h[0][1]+h[1][1])/length,
		      1., 0.,      /* x-axis same as rw */
		      /* screen contains box */
		      (fabs(h[0][0])+fabs(h[1][0]))/length,  
		      (fabs(h[0][1])+fabs(h[1][1]))/length,
		      V_DEFAULT  /* animation frames/second */
		      ));
} /* end VAddDefaultWindow() */


void VCloseWindow (int iw)
{
    active[iw] = False;
    return;
} /* end VCloseWindow() */


void VCloseAllWindows()
{
    int i;
    for (i=0; i<V_MAXWINDOW; i++)
	active[i] = False;
    return;
} /* end VCloseAllWindows() */


/* register in Object Group List */
/* and allocate space for group. */
void *VCreateOG (char token[], int obj_type, int n)
{
    struct OGL *p, *q;
    if (strlen(token)>V_MAX_OG_TOKEN_SIZE-1)
    {
	printf ("token %s should be less than %d bytes long.\n",
		token, V_MAX_OG_TOKEN_SIZE);
	exit(1);
    }
    /* root node is oglpool[0] */
    for ( p = oglpool;
	  (p->next != NULL) &&
	      strncmp(p->next->token,
		      token, V_MAX_OG_TOKEN_SIZE-1);
	  p = p->next );
    if ( p->next == NULL )
    { /* look for free space */
	for ( q = oglpool+1;
	      q < oglpool+V_MAX_NUM_OGS;
	      q++ )
	    if ( *(q->token)==(char)0 )
	    {
		p->next = q;
		q->next = NULL;
		strcpy (q->token, token);
		q->obj_type = obj_type;
		q->n = n;
		q->gp = (void *)
		    malloc (n*V_OBJ_SIZE(obj_type));
		/* set defaults to 0 */
		memset (q->gp, 0, n*V_OBJ_SIZE(obj_type));
		return (q->gp);
	    }
	printf ("error: oglpool %d records all used up.\n",
	        V_MAX_NUM_OGS-1);
	exit(1);
    }
    else
    {
	printf("error: OG token name \"%s\" already used.\n",
	       token);
	exit(1);
    }
    return (NULL);
} /* VCreateOG() */


void *VGetOG (char token[])
{
    struct OGL *p;
    for ( p = oglpool;
	  (p->next != NULL) &&
	      strncmp(p->next->token,
		      token, V_MAX_OG_TOKEN_SIZE-1);
	  p = p->next);
    if ( p->next == NULL )
    {
	printf("error: OG token name \"%s\" not found.\n",
	       token);
	exit(1);
    }
    else
	return (p->next->gp);
    return (NULL);
} /* VGetOG() */


void VDeleteOG (char token[])
{
    struct OGL *p;
    /* destroy this record and free resources */
    for ( p = oglpool;
	  (p->next != NULL) &&
	      strncmp(p->next->token,
		      token, V_MAX_OG_TOKEN_SIZE-1);
	  p = p->next);
    if ( p->next == NULL )
    {
	printf("error: token name \"%s\" not found.\n", token);
	exit(1);
    }
    else
    {
	free (p->next->gp);
	*(p->next->token) = (char)0;
	p->next = p->next->next;
	return;
    }
} /* VDeleteOG() */


#ifndef _NOTEST

void *colorful (char name[], int n)
{
    int i;
    VCIRCLE *circles; 
    VLock();
    circles = (VCIRCLE *)
	VCreateOG (name, V_CIRCLE, n);
    for (i=0; i<n; i++)
    {
	circles[i].s[0] = frandom();
	circles[i].s[1] = frandom();
	circles[i].radius = 0.25;
	circles[i].cid = V_BLACK+1+
	    floor((V_WHITE-V_BLACK)*frandom());
	if (frandom()>0.5)
	    circles[i].cid = -circles[i].cid;
    }
    VUnLock();
    return((void *)circles);
}

void *box (char *name)
{
    VPOINT *box;
    VLock();
    box = (VPOINT *) VCreateOG(name, V_POINT, 4);
    /* everything is by default 0, so */
    box[0].s[0] = 0.3; box[0].s[1] = 0.3; box[0].size=1; box[0].cid=V_GREEN;
    box[1].s[0] = 0.7; box[1].s[1] = 0.3; box[1].size=1; box[1].cid=V_GREEN;
    box[2].s[0] = 0.7; box[2].s[1] = 0.7; box[2].size=1; box[2].cid=V_GREEN;
    box[3].s[0] = 0.3; box[3].s[1] = 0.7; box[3].size=1; box[3].cid=V_GREEN;
    box[0].lcid = V_WHITE;
    box[1].lcid = V_WHITE;
    box[2].lcid = V_WHITE;
    box[3].lcid = V_WHITE;
    VUnLock();
    return((void *)box);
} /* end box() */

void *testline (char *name)
{
    VLINE *line;
    VLock();
    line = (VLINE *) VCreateOG (name, V_LINE, 1);
    line[0].s[0]=0.1;
    line[0].s[1]=0.2;
    line[0].s[2]=0.7;
    line[0].s[3]=0.9;
    line[0].cid = V_BLUE;
    VUnLock();
    return((void *)line);
} /* end bound_box() */

void main()
{
    double H[2][2] = {{12.9, 0},{0, 12.9}};
    int i; Bool second = False;
    VCIRCLE *circle;
    VLINE *line = (VLINE *)testline("line");
    VPOINT *point = (VPOINT *) box("box");
    /* default view setup */
    VAddDefaultWindow ((volatile double(*)[2])H);
    watch ("animation", 0);
    while (watch("animation", 1)<3600.)
    {
        if ( (!second) && (watch ("animation", 1)>5))
        {
	    VLock();
	    circle = (VCIRCLE *) colorful ("colorful", 30);
	    VUnLock();
	    second = True;
        }
	if (second)
	{
	    VLock();
	    for (i=0; i<30; i++)
	    {
		circle[i].s[0] += (frandom()-0.5)*0.005;
		circle[i].s[1] += (frandom()-0.5)*0.005;
	    }
	    VUnLock();
	}
	waitfor(0.01);
    }
    printf ("Master process time up.\n");
    VCloseWindow(0);
    VDeleteOG("colorful");
    VDeleteOG("box");
} /* end main() */
#endif
