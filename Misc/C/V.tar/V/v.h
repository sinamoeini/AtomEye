/***************************/
/* Header file of View 1.0 */
/***************************/

#ifndef _V_H
#define _V_H

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <pthread.h>
#include <signal.h>
#include "utils.h"

/* list of supported objects */
#define V_POINT  1
#define V_CIRCLE 2
#define V_LINE   3
#define V_OBJ_SIZE(i) \
(i==V_POINT?sizeof(VPOINT): \
 i==V_CIRCLE?sizeof(VCIRCLE): \
 i==V_LINE?sizeof(VLINE):0)
#define V_MAXWINDOW 4
#define V_MAXCOLOR  8
#define V_RESOLUTION 400
#define V_MAX_NUM_OGS 128
#define V_MAX_STRLEN  64
#define V_MAX_OG_TOKEN_SIZE 16
#define V_HUGE (10000000)
#define V_TINY (1E-7)
#define V_SIGNAL SIGUSR1
/* key to defaults */
#define V_DEFAULT (0.6565263266254E8)
#define V_DEFAULT_REFRESHRATE (24.)
#define V_DEFAULT_DBLE_CLICK_IN_MS (250)

typedef struct 
{
    double s[2];  /* position */
    int size;     /* radius in screen pixels */
    int cid;      /* if positive, then filled */
    int lcid;     /* if !=0 draw a line to the next point */
} VPOINT;

typedef struct 
{
    double s[2];    /* position */
    double radius;  /* actual size -- zoomable */
    int cid;        /* if positive, then filled */
} VCIRCLE;

typedef struct 
{
    double s[4];  /* start and end positions */
    int cid;      /* >0, solid line; <0, dash line */
} VLINE;

/* color names */
#define V_BLACK 1
#define V_RED   2
#define V_GREEN 3
#define V_BLUE  4
#define V_CYAN  5
#define V_MAGENTA 6
#define V_YELLOW  7
#define V_WHITE   8

/* function declarations */
void VSignIn (volatile double H[2][2]);
void VLock();
void VSetPBC (int iw, Bool PBC);
void *VCreateOG (char token[], int obj_type, int n);
void *VGetOG (char token[]);
void VDeleteOG (char token[]);
void VUnLock();
int VAddWindow (char address[], char title[], 
		volatile double H[2][2],
		double unit,
		double wx, double wy,
		double xx, double xy,
		double width, double height,
		double refreshrate);
int VAddDefaultWindow (volatile double H[2][2]);
void VCloseWindow (int iw);
void VCloseAllWindows();
#endif
