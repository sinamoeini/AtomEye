#ifndef _UTILS_H
#define _UTILS_H

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <bstring.h>
#include <sys/time.h>

double frandom();
void randnorm (int n, double x[]);
int freetowrite (char filename[]);
double watch(char token[], int command);
void waitfor (double seconds);
char *earth_time (double seconds);

#endif
