/***************************************/
/*  Window 2.0                         */
/*                                     */
/*  Threaded X Window 3D Object Group  */
/*  Animator inspired by Display 1.0.  */
/*                                     */
/*                     Ju Li 1998 MIT  */
/***************************************/

#ifndef _W_H
#define _W_H

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <pthread.h>
#include <signal.h>
#include "utils.h"

#define W_VERSION 2.0
#define W_PI (acos(-1.))
/* list of supported objects */
#define W_LINE   1
#define W_POINT  2
#define W_SPHERE 3
#define W_OBJ_SIZE(i) \
(i==W_POINT?sizeof(WPOINT): \
 i==W_LINE?sizeof(WLINE): \
 i==W_SPHERE?sizeof(WSPHERE):0)
#define W_MAXWINDOW (4)
#define W_MAXCOLOR  (8)
#define W_RESOLUTION (540)
#define W_MAX_NUM_OGS (128)
#define W_MAX_STRLEN (64)
#define W_MAX_OG_TOKEN_SIZE (16)
#define W_HUGE (10000000)
#define W_TINY (1E-7)
#define W_SIGNAL (SIGUSR1)
#define W_COLOR_RESOLUTION (64)
#define W_COLOR_GRADE (W_COLOR_RESOLUTION/4)
#define W_MIN_SEG_LENGTH (9.)
#define W_MAX_BUFFER (16*1024)
#define W_GOLDEN_RATIO ((-1+sqrt(5.))/2)
#define W_ORDER_BY_R  0
#define W_ORDER_BY_Z  1
#define W_ORDER_NAME(i) \
(i==W_ORDER_BY_R?"W_ORDER_BY_R": \
 i==W_ORDER_BY_Z?"W_ORDER_BY_Z":"error")
#define W_DEFAULT_ORDER (W_ORDER_BY_Z)
#define W_EYE_PIVOT       1
#define W_MID_PIVOT       2
#define W_VIEWPLATE_PIVOT 3
#define W_OBJECTS_PIVOT   4
#define W_PIVOT_NAME(i) \
(i==W_EYE_PIVOT?"W_EYE_PIVOT": \
 i==W_MID_PIVOT?"W_MID_PIVOT": \
 i==W_VIEWPLATE_PIVOT?"W_VIEWPLATE_PIVOT": \
 i==W_OBJECTS_PIVOT?"W_OBJECTS_PIVOT":"error")
#define W_TUNNEL_CID (W_WHITE)
#define W_MGS_CID    (-W_WHITE)
#define W_CROSS_CID  (W_WHITE)
#define W_PBC_FRAME_CID (W_BLUE)
#define W_TOUCH_CID  (W_RED)
#define W_TOUCH_SIZE (2)
/* key to defaults */
#define W_DEFAULT (65652430.76291)
#define W_DEFAULT_PBC (True)
#define W_DEFAULT_EYE (1.00)
#define W_DEFAULT_EYE_THICKNESS_FACTOR (1-W_TINY)
#define W_DEFAULT_ALPHA (0.65)
#define W_DEFAULT_BETA  (0.00)
#define W_DEFAULT_FACTOR (0.01)
#define W_DEFAULT_EYE_AID (1) /* draw everything */
#define W_DEFAULT_REFRESHRATE (24.)
#define W_DEFAULT_DBLE_CLICK_IN_MS (250)
#define W_PS_INCH_RESOLUTION (80.)
#define W_PS_COLOR_AMPLIFICATION (1.25)

typedef struct 
{
    double s[3];  /* position */
    int size;     /* radius in screen pixels */
    int cid;      /* if positive, then filled */
    int lcid;     /* if !=0 draw a line of lcid to the next point */
} WPOINT;

typedef struct 
{
    double s[3];    /* position */
    double radius;  /* actual size -- zoomable */
    int cid;        /* if positive, then filled */
} WSPHERE;

typedef struct 
{
    double s[6];  /* start and end positions */
    int cid;      /* >0, solid line; <0, dash line */
} WLINE;

/* color names */
#define W_BLACK 1
#define W_RED   2
#define W_GREEN 3
#define W_BLUE  4
#define W_CYAN  5
#define W_MAGENTA 6
#define W_YELLOW  7
#define W_WHITE   8

/* user function declarations */
void WLock();
void *WCreateOG (char token[], int obj_type, int n);
void *WGetOG (char token[]);
void WDeleteOG (char token[]);
int WDeleteAllOGs();
void WUnLock();
int WAddWindow (char address[],
		char title[],
		volatile double h[3][3],
		double unit,
		Bool PBC, 
		double wx, double wy,
		double wz,
		double xx, double xy, double xz,
		double yx, double yy, double yz,
		double width, double height,
		double eye,
		double eye_thickness_factor,
		double plate_thickness,
		int order_scheme,
		double alpha, double beta,
		double factor,
		int eye_aid,
		double refreshrate);
int WAddDefaultWindow (double H[3][3]);
void WCloseWindow (int iw);
void WCloseAllWindows();
#endif
