/***************************/
/* Encapsulated Postscript */
/* Output version 1.0      */
/*                         */
/*  Ju Li Jan. 9 1998 MIT  */
/***************************/

#ifndef _P_H
#define _P_H

#include "utils.h"
#define P_VERSION 1.0
#define P_MAX_STRLEN (64)
#define INCH_IN_M (0.3048006096012/12)
#define P_PAPER_WIDTH_INCH  (8.5)
#define P_PAPER_HEIGHT_INCH (11.0)
#define P_POSTSCRIPT_INCH (72)
#define P_TINY (0.00001)
#define P_HUGE (1000000)
#define P_PI (acos(-1.))
#define P_DEFAULT (7893583.41561)
#define P_DEFAULT_FILENAME "stdout"
#define P_GOLDEN_RATIO ((-1+sqrt(5.))/2)
#define P_DASHLINE_M (0.0014)
#define P_DASHLINE_INCH (P_DASHLINE_M/INCH_IN_M)
#define P_DASHLINE_RATIO P_GOLDEN_RATIO
#define P_LINE 1
#define P_FILL 2
#define P_CLIP 3
#define P_NAME(i) \
(i==P_LINE?"stroke": \
 i==P_FILL?"fill": \
 i==P_CLIP?"clip stroke":"error")

void PTran (int n, double *in, double *out);
void PDrawLine(double x0, double y0, double x1, double y1);
void PDrawRectangle
(double x0, double y0, double width, double height, int op);
void PDrawDashLine(double x0, double y0, double x1, double y1);
void PDrawDashRectangle
(double x0, double y0, double width, double height);
void PDrawCircle (double x0, double y0, double r, int Filled);
void PDrawDashCircle (double x0, double y0, double r);
void PSetRGBColor (double red, double green, double blue);
FILE *PInit (char *filename,
	     double xx_inch, double xy_inch,
	     double yx_inch, double yy_inch,
	     double ox_inch, double oy_inch,
	     double x_mesh, double y_mesh);
char *PClose();

#endif
