/***************************/
/* Encapsulated Postscript */
/* Output version 1.0      */
/*                         */
/*  Ju Li Jan. 9 1998 MIT  */
/***************************/

#include "P.h"

/* the only bootstrapping bit */
static int P_in_use = 0;
/* needed to be preset */
static char filename[P_MAX_STRLEN+1];
static FILE *P;
static double H[2][2], O[2], M[2], C[2];
/* the following has to be initialized by P */
static double lred, lgreen, lblue;

#define default(b,A,C,d) (((b)==(A)(C))?(d):(b))
#define normal(a) (((a)>=-P_TINY)&&((a)<=1+P_TINY))
#define same(a,b) (((a)>(b)-P_TINY)&&((a)<(b)+P_TINY))
#define norm(x,y) (sqrt((x)*(x)+(y)*(y)))
#define max(x,y)  ((x)>(y)?(x):(y))


/* Transform a point on rectangular domain (0,M[0]) * (0,M[1])   */
/* to Postscript coordinates on paper according to H[][] and O[] */
void PTran (int n, double *in, double *out)
{
    int i;
    double inr[2];
    for (i=0; i<n; in+=2,out+=2,i++)
    {
	inr[0] = in[0] / M[0];
	inr[1] = in[1] / M[1];
	/* H[0][] and H[1][] are the two sides in inches */
	out[0] = inr[0]*H[0][0] + inr[1]*H[1][0];
	out[1] = inr[0]*H[0][1] + inr[1]*H[1][1];
	/* O[] is origin in inches */
	out[0] += O[0];	out[1] += O[1];
	out[0] *= P_POSTSCRIPT_INCH;
	out[1] *= P_POSTSCRIPT_INCH; 
    }
    return;
} /* end PTran() */


void PDrawLine(double x0, double y0, double x1, double y1)
{
    double x[4], xx[4];
    x[0]=x0; x[1]=y0; x[2]=x1; x[3]=y1;
    PTran (2, x, xx);
    fprintf (P, "%.2f %.2f moveto ", xx[0], xx[1]);
    fprintf (P, "%.2f %.2f lineto ", xx[2], xx[3]);
    fprintf (P, "stroke\n");
    return;
} /* end PDrawLine() */


void PDrawRectangle
(double x0, double y0, double width, double height, int op)
{
    double x[8], xx[8];
    /* rectangle in the original domain */
    x[0]=x0;       x[1]=y0;
    x[2]=x0+width; x[3]=y0;
    x[4]=x0+width; x[5]=y0+height; 
    x[6]=x0;       x[7]=y0+height; 
    PTran (4, x, xx);
    fprintf (P, "%.2f %.2f moveto\n", xx[0], xx[1]);
    fprintf (P, "%.2f %.2f lineto\n", xx[2], xx[3]);
    fprintf (P, "%.2f %.2f lineto\n", xx[4], xx[5]);
    fprintf (P, "%.2f %.2f lineto\n", xx[6], xx[7]);
    fprintf (P, "closepath %s\n", P_NAME(op));
    return;
} /* end PDrawRectangle() */


void PDrawDashLine(double x0, double y0, double x1, double y1)
{
    int n;
    double x[4], xx[4], tot, segs;
    x[0]=x0; x[1]=y0; x[2]=x1; x[3]=y1;
    PTran (2, x, xx);
    tot = norm(xx[2]-xx[0], xx[3]-xx[1]);
    n = ceil(tot / P_POSTSCRIPT_INCH / P_DASHLINE_INCH);
    segs = n - 1 + P_DASHLINE_RATIO;
    fprintf (P, "gsave %.2f %.2f translate\n", xx[0], xx[1]);
    fprintf (P, "%d {0 0 moveto %.5f %.5f lineto\n",
	     n, P_DASHLINE_RATIO*(xx[2]-xx[0])/segs,
	     P_DASHLINE_RATIO*(xx[3]-xx[1])/segs );
    fprintf (P, "%.5f %.5f translate} repeat stroke grestore\n",
	     (xx[2]-xx[0])/segs, (xx[3]-xx[1])/segs);
    return;
} /* end PDrawDashLine() */


void PDrawDashRectangle
(double x0, double y0, double width, double height)
{
    PDrawDashLine(x0,       y0, x0+width, y0);
    PDrawDashLine(x0+width, y0, x0+width, y0+height);
    PDrawDashLine(x0+width, y0+height, x0, y0+height);
    PDrawDashLine(x0,       y0+height, x0, y0);
    return;
} /* end PDrawDashRectangle() */


/* draw a circle with the same area even if H[][] is tilted */
void PDrawCircle (double x0, double y0, double r, int op)
{
    double x[2], xx[2], radius;
    x[0] = x0; x[1] = y0;
    PTran (1, x, xx);
    radius = sqrt(fabs((H[0][0]*H[1][1]-H[0][1]*H[1][0])/M[0]/M[1]))
	* P_POSTSCRIPT_INCH * r;
    fprintf (P, "%.2f %.2f %.2f %.2f %.2f arc ",
	     xx[0], xx[1], radius, 0., 360.);
    fprintf (P, "%s\n", P_NAME(op));
    return;
} /* end PDrawCircle() */


void PDrawDashCircle (double x0, double y0, double r)
{
    int segs;
    double x[2], xx[2], radius;
    x[0] = x0; x[1] = y0;
    PTran (1, x, xx);
    radius = sqrt(fabs((H[0][0]*H[1][1]-H[0][1]*H[1][0])/M[0]/M[1]))
	* P_POSTSCRIPT_INCH * r;
    segs = ceil(2*P_PI*radius/P_POSTSCRIPT_INCH/P_DASHLINE_INCH); 
    fprintf (P, "gsave %.2f %.2f translate\n", xx[0], xx[1]);
    fprintf (P, "%d {%.5f %.5f moveto %.5f %.5f lineto\n",
	     segs, -P_PI/segs*radius*P_DASHLINE_RATIO, radius,
	     P_PI/segs*radius*P_DASHLINE_RATIO, radius);
    fprintf (P, "%.7f rotate} repeat stroke grestore\n",
	     360./segs);
    return;
} /* end PDrawDashCircle() */


/* red, green, blue should be inside [0,1] */
void PSetRGBColor (double red, double green, double blue)
{
    double m;
    if ((!normal(red))||(!normal(green))&&(!normal(blue)))
    {
	red   = fabs(red);
	green = fabs(green);
	blue  = fabs(blue);
	m = max(max(red,green),blue);
	red   /= m;
	green /= m;
	blue  /= m;
    }
    /* avoid redundant requests */
    if (same(red,lred)&&same(green,lgreen)&&same(blue,lblue)) return;
    fprintf (P, "%.5f %.5f %.5f setrgbcolor\n", red, green, blue);
    lred = red; lgreen = green; lblue = blue;
    return;
} /* end PSetRGBColor() */


FILE *PInit (char *pfilename,
	     double xx_inch, double xy_inch,
	     double yx_inch, double yy_inch,
	     double ox_inch, double oy_inch,
	     double x_mesh,  double y_mesh)
{
    /* P is not a multi-user device */
    if (P_in_use) return (NULL);
    if (!strcasecmp(pfilename, "P_DEFAULT"))
	strncpy (filename, P_DEFAULT_FILENAME, P_MAX_STRLEN);
    else strncpy (filename, pfilename, P_MAX_STRLEN);
    if (!strcasecmp(filename, "stdout")) P = stdout;
    else P = fopen (filename, "w+");
    if (P == NULL)
    {
	printf ("P: can not open file \"%s\".\n", filename);
	return (NULL);
    }
    P_in_use = 1;
    fprintf(P, "%%!PS-Adobe-2.0 EPSF-1.2\n");
    H[0][0] = default(xx_inch, double, P_DEFAULT, 
		      P_GOLDEN_RATIO*P_PAPER_HEIGHT_INCH);
    H[0][1] = default(xy_inch, double, P_DEFAULT, 0);
    H[1][0] = default(yx_inch, double, P_DEFAULT, 0);
    H[1][1] = default(yy_inch, double, P_DEFAULT, 
		      P_GOLDEN_RATIO*P_PAPER_HEIGHT_INCH);
    /* shift this parallel-piped to the center */
    O[0] = default(ox_inch, double, P_DEFAULT, 
		   (P_PAPER_WIDTH_INCH-H[0][0]-H[1][0])/2);
    O[1] = default(oy_inch, double, P_DEFAULT, 
		   (P_PAPER_HEIGHT_INCH-H[0][1]-H[1][1])/2);
    /* center of this drawing on paper */
    C[0] = O[0] + (H[0][0]+H[1][0]) / 2.; 
    C[1] = O[1] + (H[0][1]+H[1][1]) / 2.; 
    /* input by default is [0,1] coordinated */
    M[0] = default(x_mesh, double, P_DEFAULT, 1.);
    M[1] = default(y_mesh, double, P_DEFAULT, 1.);
    /* set initial counters */
    lred = lblue = lgreen = -P_HUGE;
    /* EPS bounding box */
    fprintf(P, "%%%%BoundingBox: %.2f %.2f %.2f %.2f\n",
	    (C[0]-(fabs(H[0][0])+fabs(H[1][0]))/2)*P_POSTSCRIPT_INCH,
	    (C[1]-(fabs(H[0][1])+fabs(H[1][1]))/2)*P_POSTSCRIPT_INCH,
	    (C[0]+(fabs(H[0][0])+fabs(H[1][0]))/2)*P_POSTSCRIPT_INCH,
	    (C[1]+(fabs(H[0][1])+fabs(H[1][1]))/2)*P_POSTSCRIPT_INCH);
    fprintf(P, "%%%%Generated by P v%.2f <liju99@mit.edu>.\n",
	    P_VERSION );
    PSetRGBColor(0,0,0);
    /* physically draw out and clip the H[2][] domain */
    PDrawRectangle (0, 0, M[0], M[1], P_CLIP);
    return (P);
} /* end PInit() */


char *PClose ()
{
    fprintf(P, "showpage\n");
    fclose(P);
    P_in_use = 0;
    return (filename);
} /* end PClose() */


#ifdef P_TEST
int main (int argc, char *argv[])
{
    PInit( (argc>1)?argv[1]:"P_DEFAULT", 
	   P_DEFAULT, 0.5,  /* H[0][] in inches */
	   0.5, P_DEFAULT, /* H[1][] in inches */
	   P_DEFAULT, P_DEFAULT, /* Origin in inches */
	   P_DEFAULT, P_DEFAULT  /* Unit in inches */
	   );
    /* PDrawDashRectangle (0, 0, 1, 1); */
    PSetRGBColor (1,0,0);
    PDrawDashLine (0., 0., 2., 2.);
    PSetRGBColor (0,0,1);
    PDrawDashCircle (0.5, 0.5, 0.6);
    PDrawDashCircle (0.5, 0.5, 0.3);
    PDrawDashCircle (0.5, 0.5, 0.1);
    PSetRGBColor (0,1,0);
    PDrawCircle (0.5, 0.5, 0.05, P_FILL);
    PSetRGBColor (0,0,0);
    PDrawLine (0, 1, 1, 0);
    PClose ();
    return(1);
}
#endif



