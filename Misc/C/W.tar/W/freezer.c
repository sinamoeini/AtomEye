/* Code Freezer: */
#define Code_Freezer
#ifndef Code_Freezer

void breakup
(unsigned int i, int m[3],
 double s0[3], double ds[3][3], double s[3])
{
    if (i>7) exit(1);
    m[0] = i & 1;
    m[1] = (i & 2) >> 1;
    m[2] = (i & 4) >> 2;
    s[0] = s0[0]+m[0]*ds[0][0]+m[1]*ds[1][0]+m[2]*ds[2][0];
    s[1] = s0[1]+m[0]*ds[0][1]+m[1]*ds[1][1]+m[2]*ds[2][1];
    s[2] = s0[2]+m[0]*ds[0][2]+m[1]*ds[1][2]+m[2]*ds[2][2];
    return;
} /* end breakup() */

void Render_BOX (int iw, int n, WBOX gp[])
{
    unsigned int i, j, k, l;
    static int im[3], jm[3];
    static double is[3], js[3];
    static WLINE line[12];
    for (l=0; l<n; l++)
    {
	for (k=i=0; i<8; i++)
	    for (j=i+1; j<8; j++)
		if (((i^j)==1)||
		    ((i^j)==2)||
		    ((i^j)==4))
		{
		    breakup (i, im, gp[l].s, gp[l].ds, is);
		    breakup (j, jm, gp[l].s, gp[l].ds, js);
		    line[k].s[0] = is[0];
		    line[k].s[1] = is[1];
		    line[k].s[2] = is[2];
		    line[k].s[3] = js[0];
		    line[k].s[4] = js[1];
		    line[k].s[5] = js[2];
		    line[k].cid = gp[l].cid;
		    k++;
		}
	Render_LINE (iw, 12, line);
    }
    return;
} /* end Render_BOX() */


void bound_box (char *name)
{
    WBOX *box;
    WLock();
    box = (WBOX *) WCreateOG (name, W_BOX, 1);
    box[0].s[0]=box[0].s[1]=box[0].s[2]=-0.5;
    box[0].ds[0][0]=box[0].ds[1][1]=box[0].ds[2][2]=1;
    box[0].ds[0][1]=box[0].ds[0][2]=0;
    box[0].ds[1][0]=box[0].ds[1][2]=0;
    box[0].ds[2][0]=box[0].ds[2][1]=0;
    box[0].cid = W_WHITE;
    WUnLock();
    return;
} /* end bound_box() */

#endif
/* end Code Freezer */
