
load dat.out;

plot(dat(:,1),dat(:,2));
hold on;
plot(dat(:,1),dat(:,3),'--');
