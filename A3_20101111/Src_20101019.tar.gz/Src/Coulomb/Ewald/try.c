
#include <math.h>
#include <stdio.h>

void main()
{
  printf ("%f\n", erfc(1.0));
  printf ("%f %f\n", rint(1.5),rint(-1.5));
}
