Float rmax[4][4];
