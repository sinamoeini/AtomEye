#ifndef __INTPAIR_H__
#define __INTPAIR_H__

typedef struct { int v1; int v2; } IntPair;

#endif
