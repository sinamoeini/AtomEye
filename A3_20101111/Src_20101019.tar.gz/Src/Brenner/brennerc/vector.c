#include "vector.h"

// Nothing left here.  Compilation check only.
